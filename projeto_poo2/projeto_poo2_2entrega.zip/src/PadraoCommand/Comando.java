package PadraoCommand;

public abstract class Comando {
    // Methods

    public abstract void execute();
}
