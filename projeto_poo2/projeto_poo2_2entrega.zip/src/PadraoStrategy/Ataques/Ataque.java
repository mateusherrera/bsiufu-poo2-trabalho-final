package PadraoStrategy.Ataques;

public abstract class Ataque {
    // Methods //

    public abstract int ataca();
}
