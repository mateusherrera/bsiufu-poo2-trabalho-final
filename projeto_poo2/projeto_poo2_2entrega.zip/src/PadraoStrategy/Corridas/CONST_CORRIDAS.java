package PadraoStrategy.Corridas;

public interface CONST_CORRIDAS {
    public static final int COR_MORTO =  0;
    public static final int COR_LENTA = 2;
    public static final int COR_MEDIA = 4;
    public static final int COR_VELOZ = 6;
}
