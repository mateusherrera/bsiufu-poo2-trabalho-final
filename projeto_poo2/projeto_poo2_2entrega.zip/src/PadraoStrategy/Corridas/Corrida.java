package PadraoStrategy.Corridas;

public abstract class Corrida {
    // Methods //

    public abstract int corre();
}
