package PadraoStrategy.Pulos;

public abstract class Pulo {
    // Methods //

    public abstract int pula();
}
