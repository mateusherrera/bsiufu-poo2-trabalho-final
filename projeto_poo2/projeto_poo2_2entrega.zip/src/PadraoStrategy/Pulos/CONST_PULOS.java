package PadraoStrategy.Pulos;

public interface CONST_PULOS {
    public static final int PULO_MORTO = 0;
    public static final int PULO_BAIXO = 2;
    public static final int PULO_MEDIO = 4;
    public static final int PULO_ALTO  = 6;
}
