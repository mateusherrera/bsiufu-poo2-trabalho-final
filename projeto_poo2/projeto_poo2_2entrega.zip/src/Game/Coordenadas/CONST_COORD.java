package Game.Coordenadas;

public interface CONST_COORD {
    public static final int MIN_X = 0;
    public static final int MIN_Y = 0;

    public static final int MAX_X = 1000;
    public static final int MAX_Y = 500;
}
