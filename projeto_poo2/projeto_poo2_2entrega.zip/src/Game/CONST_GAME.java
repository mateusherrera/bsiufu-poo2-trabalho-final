package Game;

public interface CONST_GAME {
    // Período //
    public static final int FUTIRISTA = 1;
    public static final int MEDIEVAL  = 2;

    // Dificuldade //
    public static final int FACIL   = 1;
    public static final int MEDIO   = 2;
    public static final int DIFICIL = 3;

    // Velocidade dos inimigos //
    public static final int VLENTO = 1;
    public static final int VMEDIO = 2;
    public static final int VVELOZ = 3;
}
