package Chars.Player;

public interface CONST_PLAYER {
    public static final int LIFE_MIN =   0;
    public static final int LIFE_MAX = 2000;
    public static final double PERC_LIFE_INI = 0.7;
}
