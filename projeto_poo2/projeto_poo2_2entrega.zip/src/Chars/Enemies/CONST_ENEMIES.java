package Chars.Enemies;

public interface CONST_ENEMIES {
    public static final int HIT_MAX   = 10;
    public static final int HIT_MORTO = 0;
}
