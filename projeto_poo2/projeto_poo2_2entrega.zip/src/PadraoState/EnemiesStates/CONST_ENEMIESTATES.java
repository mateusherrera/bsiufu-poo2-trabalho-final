package PadraoState.EnemiesStates;

public interface CONST_ENEMIESTATES {
    public static final int MORTO = 0;
}
