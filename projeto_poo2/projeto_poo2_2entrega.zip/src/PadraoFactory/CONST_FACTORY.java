package PadraoFactory;

public interface CONST_FACTORY {
    public static final double PSG_1 = 0.2;
    public static final double PSG_2 = 0.4;
    public static final double PSG_3 = 0.6;
    public static final double PSG_4 = 0.8;
}
