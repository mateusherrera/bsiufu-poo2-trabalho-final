package PadraoComposite;

public interface CONST_FASE {
    public static final int ESQUERDA = 1;
    public static final int DIREITA  = 2;
}
